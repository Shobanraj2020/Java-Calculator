package com.company;

import java.util.Arrays;

public class Multiplication {

    public void MULTIPLICATION(String Duparray[], String DoubleMul[], int m) {
        int Doublemul = 0;

        for (int i = 0; i < Duparray.length; i++) {

            if (i + 2 > Duparray.length - 1) {
                break;
            }

            if (Duparray[i].equals("*") && Duparray[i + 2].equals("*")) {
                int place1 = i - 1;
                double temp = Double.parseDouble(Duparray[i - 1]);
                for (int j = i; j < Duparray.length; j++) {
                    if (Duparray[j].equals("*")) {
                        temp *= Double.parseDouble(Duparray[j + 1]);
                        Duparray[j] = "shit";
                        Duparray[j + 1] = "shit";
                        Doublemul++;


                    } else {
                        break;
                    }
                    j++;

                }
                Duparray[place1] = String.valueOf(temp);
            }

        }
        //System.out.println("DOUBLE-MULTIPLIED ARRAY = " + Arrays.toString(Duparray) + "\nDou = " + Doublemul + "\nm = " + m);

        int shitcounter = 0, Count = 0, len = Duparray.length - 1;
        for (int i = 0; i < Duparray.length; i++) {
            if (Duparray[i].equals("shit")) {
                shitcounter++;
            }
        }
        //System.out.println("shit = " + shitcounter);

        for (int j = 0; j < Duparray.length; j++) {
            if (!Duparray[j].equals("shit")) {
                Duparray[Count] = Duparray[j];
                Count++;
            }
        }
        //System.out.println("A1 = " + Arrays.toString(Duparray));

        while (shitcounter != 0) {
            if (!Duparray[len].equals("shit")) {
                Duparray[len] = "shit";
                --len;
                --shitcounter;
            } else if (Duparray[len].equals("shit")) {
                --len;
                --shitcounter;
            }
        }
        //System.out.println("A2 = " + Arrays.toString(Duparray));

        Doublemul = m - Doublemul;
        DoubleMul[0] = String.valueOf(Doublemul);

    }

}
