package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println("WELCOME TO CALCULATOR");
        Scanner input = new Scanner(System.in);
        String Orgarray[]=new String[100];
        int count=0;
       while(10!=0){
           Orgarray[count]= input.nextLine();
           if(Orgarray[count].equals("=")){
               break;
           }else{
               count++;
           }
       }
       // System.out.println(Arrays.toString(Orgarray)+"\n"+count);
       //CREATING A DUPLICATE ARRAY...
       String Duparray[]=new String[count];

       for(int i=0;i< Duparray.length;i++){
           Duparray[i]=Orgarray[i];
       }
        System.out.println(Arrays.toString(Duparray));
       int d=0,m=0,a=0,s=0;
       for(int i=0;i< Duparray.length;i++){
           if(Duparray[i].equals("/")){
               d++;
           }else if(Duparray[i].equals("*")){
               m++;
           }else if(Duparray[i].equals("+")){
               a++;
           }else if(Duparray[i].equals("-")){
               s++;
           }
       }
        //System.out.println("d = "+d+" m = "+m+" a = "+a+" s = "+s);
       //2*12/6+43-12=
        //2*2+43-12
        //4+43-12.
        //47-12=35.


        int COUNTER=0;

        if(d>0){
            Division div=new Division();
            div.DIVISION(Duparray);


            for(int i=0;i< Duparray.length;i++){
                double Div;
                if(Duparray[i].equals("/")){
                    Div=Double.parseDouble(Duparray[i-1])/Double.parseDouble(Duparray[i+1]);
                    Duparray[i-1]=String.valueOf(Div);
                }
            }
            int count2=0;
            for(int i=0;i< Duparray.length;i++) {
                if (!Duparray[i].equals("/")) {
                    Duparray[count2] = Duparray[i];
                    count2++;
                }else{
                    i++;
                }
            }
            int len= Duparray.length-1;
            for(int i=1;i<=(d*2);i++){
                Duparray[len]="shit";
                len--;
            }
            COUNTER++;
            //System.out.println("DIV ARRAY = "+Arrays.toString(Duparray));
        }


      //  12, /, 6, *, 2, +, 23, -, 12, /, 12
        if(m>0){
            Multiplication mul=new Multiplication();
            String DoubleMul[]=new String[1];
            mul.MULTIPLICATION(Duparray,DoubleMul,m);
            //System.out.println("REMAINING * SIGN = "+DoubleMul[0]);
            m=Integer.parseInt(DoubleMul[0]);

            for(int j=0;j< Duparray.length;j++) {
                double Mul;
                if (Duparray[j].equals("*")) {
                    Mul = Double.parseDouble(Duparray[j - 1]) * Double.parseDouble(Duparray[j + 1]);
                    Duparray[j - 1] = String.valueOf(Mul);
                }
            }
                int count3=0;
                for(int j=0;j< Duparray.length;j++) {
                    if(Duparray[j].equals("shit")){
                        break;
                    }
                    if (!Duparray[j].equals("*")) {
                        Duparray[count3] = Duparray[j];
                        count3++;
                    }else{
                        j++;
                    }
                }
            //System.out.println(Arrays.toString(Duparray)+"m = "+m);

                m=m*2;
                for(int j= Duparray.length-1;j>=0;j--){
                    if(!Duparray[j].equals("shit")){
                        Duparray[j]="shit";
                        m--;
                    }
                    if(m==0){
                        break;
                    }
                }
                COUNTER++;
          //System.out.println("MULTIPLIED ARRAY = "+Arrays.toString(Duparray));
        }

        //System.out.println("A3 = "+Arrays.toString(Duparray));
        if(COUNTER>0){
            int count3=0;
            double temp;
            for(int k=0;k< Duparray.length;k++){
                if(!Duparray[k].equals("shit")){
                    count3++;
                }
            }
            //System.out.println(count3);
            String AddSub[]=new String[count3];
            for(int k=0;k< AddSub.length;k++){
                AddSub[k]=Duparray[k];
            }
            //System.out.println("ENDGAME = "+Arrays.toString(AddSub));
            temp=Double.parseDouble(AddSub[0]);
            for(int k=1;k< AddSub.length;k++){
                if(AddSub[k].equals("+")){
                    temp+=Double.parseDouble(AddSub[k+1]);
                }else if((AddSub[k].equals("-"))){
                    temp-=Double.parseDouble(AddSub[k+1]);
                }
                k++;

            }
            System.out.println(temp);

        }else if(COUNTER==0){
            //System.out.println("ENDGAME = "+Arrays.toString(Duparray));
            double Temp = Double.parseDouble(Duparray[0]);
            for(int k=1;k< Duparray.length;k++){
                if(Duparray[k].equals("+")){
                    Temp+=Double.parseDouble(Duparray[k+1]);
                }else if(Duparray[k].equals("-")){
                    Temp-=Double.parseDouble(Duparray[k+1]);
                }
                k++;
            }
            System.out.println(Temp);
        }







    }
}
/*
12, *, 2, *, 2, +, 12, /, 6, +, 23, -, 12, /, 6, /, 2,
if(COUNTER>0){
            int count3=0,temp;
            for(int k=0;k< Duparray.length;k++){
                if(!Duparray[k].equals("shit")){
                    count3++;
                }
            }
            //System.out.println(count3);
            String AddSub[]=new String[count3];
            for(int k=0;k< AddSub.length;k++){
                AddSub[k]=Duparray[k];
            }
            System.out.println("ENDGAME = "+Arrays.toString(AddSub));
            temp=Integer.parseInt(AddSub[0]);
            for(int k=1;k< AddSub.length;k++){
                if(AddSub[k].equals("+")){
                    temp+=Integer.parseInt(AddSub[k+1]);
                }else if((AddSub[k].equals("-"))){
                      temp-=Integer.parseInt(AddSub[k+1]);
                }
                k++;

            }
            System.out.println(temp);

        }else if(COUNTER==0){
            System.out.println("ENDGAME = "+Arrays.toString(Duparray));
            int Temp = Integer.parseInt(Duparray[0]);
            for(int k=1;k< Duparray.length;k++){
                if(Duparray[k].equals("+")){
                    Temp+=Integer.parseInt(Duparray[k+1]);
                }else if(Duparray[k].equals("-")){
                    Temp-=Integer.parseInt(Duparray[k+1]);
                }
                k++;
            }
            System.out.println(Temp);
        }

 */

