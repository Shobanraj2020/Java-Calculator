package com.company;

import java.util.Arrays;

public class Division {
    public void DIVISION(String Duparray[]){
        for(int i=0;i< Duparray.length;i++){
            if(i+2> Duparray.length-1){
                break;
            }
            if(Duparray[i].equals("/") && Duparray[i+2].equals("/")){
                int place1=i-1;
                double temp=Double.valueOf(Duparray[i-1]);
                //System.out.println("poda");

                for(int j=i;j< Duparray.length;j++){
                    if(Duparray[j].equals("/")){
                        temp/=Double.valueOf(Duparray[j+1]);
                        Duparray[j]="shit";
                        Duparray[j+1]="shit";
                    }else{
                        break;
                    }
                    j++;

                }
                Duparray[place1]=String.valueOf(temp);
            }
        }
        //System.out.println(Arrays.toString(Duparray));



        int Count=0;
        for(int i=0;i< Duparray.length;i++){
            if(!Duparray[i].equals("shit")){
                Duparray[Count]=Duparray[i];
                Count++;
            }
        }
        int Shitcounter= (Duparray.length-Count);
        //System.out.println(Arrays.toString(Duparray)+"\n"+Shitcounter);

        int len= Duparray.length-1;
        for(int j=1;j<=Shitcounter;j++){
            Duparray[len]="shit";
            len--;
        }
        //System.out.println(Arrays.toString(Duparray));

    }
}
